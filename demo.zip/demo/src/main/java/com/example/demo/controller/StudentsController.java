package com.example.demo.controller;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Students;
import com.example.demo.services.StudentsService;

 
@RestController
public class StudentsController {
	
	@Autowired
	StudentsService studentsService;
	

	
	@GetMapping("/students")
	private List<Students> getAllStudents() {
		return studentsService.getAllStudents();
	}


	@GetMapping("/student/{No}")
	private Students getStudents(@PathVariable("no") int No) {
		return studentsService.getStudentsByNo(No);
	}

	
	@PostMapping("/students")
	private Students saveStudents(@RequestBody Students students, HttpServletResponse response) {
		studentsService.saveOrUpdate(students);
		response.setStatus(HttpServletResponse.SC_ACCEPTED);
		return students;
	}

	
	@PutMapping("/students{No}")
	private Students update(@RequestBody Students students) {
		studentsService.saveOrUpdate(students);
		return students;
	}


	@DeleteMapping("/students/{No}")
	private void deletestudents(@PathVariable("No") int no) {
		studentsService.delete(no);
	}

}