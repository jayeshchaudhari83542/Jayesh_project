package com.example.demo.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Students;
import com.example.demo.repository.StudentsRepository;


@Service
public class StudentsService {

	@Autowired
	StudentsRepository studentsRepository;
    Students students;

	public List<Students> getAllStudents() {
		List<Students> students = new ArrayList<Students>();
		studentsRepository.findAll().forEach(students1 -> students.add(students1));
		return students;
	}

	
	public Students getStudentsByNo(int No) {
		return studentsRepository.findById(No).get();
	}


	public void saveOrUpdate(Students students) {
		studentsRepository.save(students);
	}

	
	public void delete(int No) {
		studentsRepository.deleteById(No);

	}

	
	public void update(Students students, int No) {
		studentsRepository.save(students);
	}

}