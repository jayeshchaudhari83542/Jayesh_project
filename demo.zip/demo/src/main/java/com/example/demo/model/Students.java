package com.example.demo.model;


import java.sql.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
public class Students{
	
	@Id  
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int no; 
	private String name;  
	private String dob;
	private String doj;  
	
	
	public Students() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Students(int no, String name, String dob, String doj) {
		super();
		this.no = no;
		this.name = name;
		this.dob = dob;
		this.doj = doj;
	}


	public int getNo() {
		return no;
	}


	public void setNo(int no) {
		this.no = no;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getDob() {
		return dob;
	}


	public void setDob(String dob) {
		this.dob = dob;
	}


	public String getDoj() {
		return doj;
	}


	public void setDoj(String doj) {
		this.doj = doj;
	}


	
}  